declare namespace ProtoGenerate{

    export class IProtoGenerate{
        Generate(moduleName:string, protoObj:any);   
    }
}